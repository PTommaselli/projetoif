
//Conecção com o firebase

const config = {
	apiKey: "AIzaSyCSNEPgV3iaR3GnxCByvxWT6fCA7HwLpv4",
	authDomain: "ultimo-f7d1e.firebaseapp.com",
	databaseURL: "https://ultimo-f7d1e.firebaseio.com",
	projectId: "ultimo-f7d1e",
	storageBucket: "ultimo-f7d1e.appspot.com",
	messagingSenderId: "303544299270"
};	
firebase.initializeApp(config);

//=============================================

//Pegando informações do Database do firebase

const db = firebase.database(); //buscando informações do database.
const ref = db.ref('pracas'); //pegando a referencia do database.

//=============================================

//Pegando informações da Api do Maps.

let map; //Variavel de geração do mapa.
let marker; //Variavel de gereção dos marcadores.


//=============================================



ref.on('value', function(snapshotPracas){ //|Referencía e liga(atribui) o data base a uma função,
										  //|onde tem-se um que imprime os valores do database.

  let pracas = snapshotPracas.val(); // o "val()" transforma os dados do database em valores.

  for (let i = 0; i < pracas.value.length; i++) {
    let cordLat = pracas.value[i].cord.latlng[0];
    let cordLng = pracas.value[i].cord.latlng[1];
	let name = pracas.value[i].propriedades.nome;
	let desc = pracas.value[i].esportes;
	let img = pracas.value[i].propriedades.img;
	


    marker = new google.maps.Marker({
		position:{lat: cordLat,lng: cordLng},
		map: map,
		title: name
	});

	marker.addListener("click", function(){
		document.getElementById("onoff").style.display = "flex";
		document.getElementById("title-card").innerHTML = name;
		document.getElementById("desc-card").innerHTML = desc;
		document.querySelector(".demo-card-wide > .mdl-card__title").style.background = "url('"+img+"') center / cover";
	}); 

	let exit = document.querySelector("#exit").onclick = function(){ 
		let card = document.getElementById("onoff").style.display;

		if (card == "flex") {
			document.getElementById("onoff").style.display = "none";
		}else{
			document.getElementById("onoff").style.display = "flex";
		}
	}; 
	
	 
  }

});
const DouradosCenter = {lat: -22.223617,lng: -54.812193};

function initMap(){
	map = new google.maps.Map(document.getElementById('map'), {
		center: DouradosCenter,
		zoom: 14
	});
}

