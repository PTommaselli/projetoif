
 // const config = {
 //    apiKey: "AIzaSyCSNEPgV3iaR3GnxCByvxWT6fCA7HwLpv4",
 //    authDomain: "ultimo-f7d1e.firebaseapp.com",
 //    databaseURL: "https://ultimo-f7d1e.firebaseio.com",
 //    projectId: "ultimo-f7d1e",
 //    storageBucket: "ultimo-f7d1e.appspot.com",
 //    messagingSenderId: "303544299270"
 //  };	
 //  firebase.initializeApp(config);



 //    const db = firebase.database();
 //    const ref = db.ref('pracas');

 //    ref.on('value', function(snapshotPracas){

 //      let pracas = snapshotPracas.val();

 //      for (var i = 0; i < pracas.value.length; i++) {
 //        let cordLat = pracas.value[i].cord.latlng[0];
 //        let cordLng = pracas.value[i].cord.latlng[1];
       
 //      }
 //    });  



